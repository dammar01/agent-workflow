# Exoma v1.2.3 downstream staging, 2026-11-25

Windows staging used a disposable checkout of agent-workflow at `1bcdb0b7ccb4318b2f5bd690dd6d6dcb8fef9186`. The manifest, lock and installed Exoma identify candidate `1c9d08609fc474dc1ee41f915f2d58a8057cfc90`. Exoma main pointed at this SHA during staging. All 26 jobs passed in [CI run 45579540374](https://github.com/dammar01/Exoma/actions/runs/45579540374).

| Check | Result | Evidence |
| --- | --- | --- |
| Resolve and install downstream | `uv lock` and `uv sync --locked` exited 0. The full E2E run verified installed Git identity. | candidate-pin.patch and codex-e2e.json |
| Downstream suites | All seven passed | downstream-tests.txt |
| Tracked research records | 137 records passed, zero warnings | research.txt |
| Live Codex E2E | gpt-6.1-sol, 11 passed, none skipped. Includes fresh delegated explore and local sweep. | codex-e2e.json |
| Windows updater | Six strict handoffs passed across Python 3.11 and 3.13 with uv, pipx and pip. The separate validator accepted all six reports for this SHA. | native/ and native-validate.txt |
| Chromium smoke | The initial attempt skipped for a missing binary. The final run with the candidate's Playwright and a staged Chromium passed in 196.7 seconds. | browser.txt |
| Distribution | Version stamp, bundle manifest, locked dependency check and sdist-to-wheel build passed. | dist/ in staging workspace |

The project-local ignored drafts were checked in the original checkout with the candidate staging interpreter. EXP-021 has a pre-existing schema error at `threats_to_validity[3]`. Six older draft decisions have warnings about placeholder commit references. The tracked records passed separately. Interactive host approval and deployment were outside the CLI E2E coverage.

The original agent-workflow checkout remains pinned to its previous revision. Its cross-project write hook refused the edit. The two-file candidate-pin.patch passed `git apply --check` there. The staging run created no commits, release tags or publications.
